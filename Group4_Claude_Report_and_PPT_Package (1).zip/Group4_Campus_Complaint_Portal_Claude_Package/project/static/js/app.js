document.addEventListener('DOMContentLoaded', () => {
    fetchStats();
    fetchComplaints();

    // Attach form submission handler
    const complaintForm = document.getElementById('complaint-form');
    complaintForm.addEventListener('submit', handleCreateComplaint);
});

// GET: Fetch dashboard metrics
async function fetchStats() {
    try {
        const response = await fetch('/api/stats');
        const data = await response.json();
        
        document.getElementById('stat-total').innerText = data.total;
        document.getElementById('stat-pending').innerText = data.pending;
        document.getElementById('stat-in-progress').innerText = data.in_progress;
        document.getElementById('stat-resolved').innerText = data.resolved;
    } catch (error) {
        console.error("Error fetching stats:", error);
    }
}

// GET: Fetch and display complaints with optional filters
async function fetchComplaints() {
    const status = document.getElementById('filter-status').value;
    const category = document.getElementById('filter-category').value;
    
    let url = `/api/complaints?`;
    if (status) url += `status=${encodeURIComponent(status)}&`;
    if (category) url += `category=${encodeURIComponent(category)}`;

    try {
        const response = await fetch(url);
        const resData = await response.json();
        
        const container = document.getElementById('complaints-list');
        container.innerHTML = '';

        if (!resData.data || resData.data.length === 0) {
            container.innerHTML = `<p style="color: #64748b; text-align: center; padding: 20px;">No complaints found.</p>`;
            return;
        }

        resData.data.forEach(item => {
            const card = document.createElement('div');
            card.className = 'ticket-card';
            
            const badgeClass = item.status === 'Resolved' 
                ? 'tag-resolved' 
                : item.status === 'In Progress' 
                    ? 'tag-in-progress' 
                    : 'tag-pending';

            card.innerHTML = `
                <div class="ticket-top">
                    <h4>${escapeHtml(item.title)}</h4>
                    <span class="tag ${badgeClass}">${item.status}</span>
                </div>
                <div class="ticket-meta">
                    <span>📍 <strong>Location:</strong> ${escapeHtml(item.location)}</span>
                    <span>📂 <strong>Category:</strong> ${escapeHtml(item.category)}</span>
                    <span>👤 <strong>By:</strong> ${escapeHtml(item.reporter_name)}</span>
                </div>
                <p style="font-size: 0.9rem; color: #334155;">${escapeHtml(item.description)}</p>
                
                ${item.resolution_notes ? `
                    <div class="resolution-box">
                        <strong>Resolution Note:</strong> ${escapeHtml(item.resolution_notes)}
                    </div>
                ` : ''}

                <div class="ticket-actions">
                    <button class="btn btn-secondary" onclick="openUpdateModal(${item.id}, '${item.status}', \`${escapeHtml(item.resolution_notes || '')}\`)">Update Status</button>
                    <button class="btn btn-danger" onclick="deleteComplaint(${item.id})">Delete</button>
                </div>
            `;
            container.appendChild(card);
        });
    } catch (error) {
        console.error("Error loading complaints:", error);
    }
}

// POST: Add a new complaint
async function handleCreateComplaint(e) {
    e.preventDefault();

    const payload = {
        reporter_name: document.getElementById('reporter_name').value,
        title: document.getElementById('title').value,
        category: document.getElementById('category').value,
        location: document.getElementById('location').value,
        description: document.getElementById('description').value
    };

    try {
        const response = await fetch('/api/complaints', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const data = await response.json();
        if (data.success) {
            document.getElementById('complaint-form').reset();
            fetchComplaints();
            fetchStats();
        } else {
            alert(data.error || "Failed to submit ticket");
        }
    } catch (err) {
        console.error("Error posting complaint:", err);
    }
}

// PATCH/PUT: Update Status & Resolution Notes Modal Handling
function openUpdateModal(id, currentStatus, currentNotes) {
    document.getElementById('modal-complaint-id').value = id;
    document.getElementById('modal-status').value = currentStatus;
    document.getElementById('modal-notes').value = currentNotes;
    document.getElementById('updateModal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('updateModal').style.display = 'none';
}

async function saveStatusUpdate() {
    const id = document.getElementById('modal-complaint-id').value;
    const status = document.getElementById('modal-status').value;
    const resolution_notes = document.getElementById('modal-notes').value;

    try {
        const response = await fetch(`/api/complaints/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status, resolution_notes })
        });

        const data = await response.json();
        if (data.success) {
            closeModal();
            fetchComplaints();
            fetchStats();
        } else {
            alert(data.error || "Failed to update record");
        }
    } catch (err) {
        console.error("Error updating complaint:", err);
    }
}

// DELETE: Delete complaint
async function deleteComplaint(id) {
    if (!confirm("Are you sure you want to delete this complaint?")) return;

    try {
        const response = await fetch(`/api/complaints/${id}`, {
            method: 'DELETE'
        });
        const data = await response.json();
        if (data.success) {
            fetchComplaints();
            fetchStats();
        } else {
            alert(data.error || "Failed to delete record");
        }
    } catch (err) {
        console.error("Error deleting complaint:", err);
    }
}

// Security utility: escape HTML to avoid XSS
function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, "&amp;")
              .replace(/</g, "&lt;")
              .replace(/>/g, "&gt;")
              .replace(/"/g, "&quot;")
              .replace(/'/g, "&#039;");
}