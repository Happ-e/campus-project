from flask import Flask, request, jsonify, render_template
from database import get_db_connection, init_db

app = Flask(__name__)

# Initialize database table on application start
init_db()

@app.route('/')
def home():
    """Serves the single-page application frontend."""
    return render_template('index.html')

# ----------------- RESTful API ROUTES ----------------- #

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Returns counts of total, pending, in-progress, and resolved complaints."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT COUNT(*) FROM complaints')
    total = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM complaints WHERE status = 'Pending'")
    pending = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM complaints WHERE status = 'In Progress'")
    in_progress = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM complaints WHERE status = 'Resolved'")
    resolved = cursor.fetchone()[0]
    
    conn.close()
    return jsonify({
        "total": total,
        "pending": pending,
        "in_progress": in_progress,
        "resolved": resolved
    }), 200

@app.route('/api/complaints', methods=['GET'])
def get_complaints():
    """Retrieve all complaints with optional filtering."""
    status_filter = request.args.get('status')
    category_filter = request.args.get('category')
    
    query = "SELECT * FROM complaints WHERE 1=1"
    params = []
    
    if status_filter:
        query += " AND status = ?"
        params.append(status_filter)
    if category_filter:
        query += " AND category = ?"
        params.append(category_filter)
        
    query += " ORDER BY id DESC"
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()
    
    complaints = [dict(row) for row in rows]
    return jsonify({"success": True, "data": complaints}), 200

@app.route('/api/complaints/<int:complaint_id>', methods=['GET'])
def get_complaint(complaint_id):
    """Retrieve details of a single complaint."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM complaints WHERE id = ?", (complaint_id,))
    row = cursor.fetchone()
    conn.close()
    
    if row is None:
        return jsonify({"success": False, "error": "Complaint not found"}), 404
        
    return jsonify({"success": True, "data": dict(row)}), 200

@app.route('/api/complaints', methods=['POST'])
def create_complaint():
    """Register a new complaint."""
    data = request.get_json()
    
    if not data:
        return jsonify({"success": False, "error": "Request body must be JSON"}), 400
        
    title = data.get('title', '').strip()
    category = data.get('category', '').strip()
    location = data.get('location', '').strip()
    description = data.get('description', '').strip()
    reporter_name = data.get('reporter_name', '').strip()
    
    # Input Validation
    if not all([title, category, location, description, reporter_name]):
        return jsonify({"success": False, "error": "All fields are required"}), 422
        
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO complaints (title, category, location, description, reporter_name)
        VALUES (?, ?, ?, ?, ?)
    ''', (title, category, location, description, reporter_name))
    conn.commit()
    new_id = cursor.lastrowid
    conn.close()
    
    return jsonify({
        "success": True, 
        "message": "Complaint logged successfully", 
        "id": new_id
    }), 201

@app.route('/api/complaints/<int:complaint_id>', methods=['PATCH', 'PUT'])
def update_complaint(complaint_id):
    """Update status and resolution notes of an existing complaint."""
    data = request.get_json()
    if not data:
        return jsonify({"success": False, "error": "Invalid request body"}), 400
        
    status = data.get('status')
    resolution_notes = data.get('resolution_notes')
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM complaints WHERE id = ?", (complaint_id,))
    complaint = cursor.fetchone()
    
    if not complaint:
        conn.close()
        return jsonify({"success": False, "error": "Complaint not found"}), 404
        
    new_status = status if status else complaint['status']
    new_notes = resolution_notes if resolution_notes is not None else complaint['resolution_notes']
    
    cursor.execute('''
        UPDATE complaints 
        SET status = ?, resolution_notes = ? 
        WHERE id = ?
    ''', (new_status, new_notes, complaint_id))
    conn.commit()
    conn.close()
    
    return jsonify({"success": True, "message": "Complaint updated successfully"}), 200

@app.route('/api/complaints/<int:complaint_id>', methods=['DELETE'])
def delete_complaint(complaint_id):
    """Delete a complaint record."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM complaints WHERE id = ?", (complaint_id,))
    if not cursor.fetchone():
        conn.close()
        return jsonify({"success": False, "error": "Complaint not found"}), 404
        
    cursor.execute("DELETE FROM complaints WHERE id = ?", (complaint_id,))
    conn.commit()
    conn.close()
    
    return jsonify({"success": True, "message": "Complaint deleted successfully"}), 200

if __name__ == '__main__':
    app.run(debug=True, port=5000)