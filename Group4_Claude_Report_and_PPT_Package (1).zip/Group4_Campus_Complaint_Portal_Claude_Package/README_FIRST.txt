GROUP 4 — CAMPUS COMPLAINT AND MAINTENANCE PORTAL
Claude handoff package

START HERE:
1. Open CLAUDE_MASTER_BRIEF.md. It contains the complete prompt, verified project description, report structure, slide plan, and strict accuracy rules.
2. project/ contains the supplied application files arranged in the Flask folder structure expected by the HTML.
3. references/ contains the college worksheet and the other group's report and presentation PDFs. Those PDFs are examples for format/design only, not content to copy.

Important:
- Group 4 members: Kush (2026UCD3136), Kinshuk (2026UCD2173), Akshat (2026UCD3123).
- The supplied SQLite database has an empty complaints table.
- No Group 4 app screenshots or test evidence were supplied. Do not invent them.
- The project code is the source of truth for implemented functionality.
