# CLAUDE MASTER BRIEF — GROUP 4
## Campus Complaint and Maintenance Portal
**Purpose:** Use this package to create BOTH (1) a polished academic mini-project report and (2) a matching PowerPoint presentation for Group 4.

---

## 1. Instructions to Claude

Create a complete, submission-ready project report and a presentation using the supplied project files as the factual source of truth.

**Important source hierarchy**
1. The `project/` folder contains Group 4's actual implementation. Describe only functionality supported by these files.
2. `references/Mini_Project_Guidelines_and_Worksheet.docx` contains the college's mini-project expectations.
3. The two PhishWise PDFs in `references/` are examples from another group. Use them ONLY as references for report organization, slide pacing, visual quality, and level of technical explanation. Do not copy their project title, names, roll numbers, functionality, screenshots, testing claims, or technical details.
4. The assignment-list image identifies Group 4 and its members.

Do not invent missing information, test results, deployment details, screenshots, user counts, or contributions. Where evidence is absent, use a clearly marked placeholder such as `[Add actual application screenshot]` or `[Confirm individual contribution]`, or state that the information was not supplied. Do not fabricate UI screenshots. If a detail is uncertain, flag it for the students.

Produce:
- A detailed but concise academic report in editable DOCX format, with a PDF export if possible.
- A PowerPoint presentation in editable PPTX format.
- Consistent typography, colors, diagrams, headings, and terminology across both deliverables.
- A final checklist of details Group 4 must verify before submission.

## 2. Group and project identity

**Group:** 4  
**Project title:** Campus Complaint and Maintenance Portal  
**Project domain:** Campus facilities, complaint registration, and maintenance tracking  
**Institution:** Netaji Subhas University of Technology (NSUT)  
**Academic year:** 2026

**Members (copy names and roll numbers exactly):**
- Kush — 2026UCD3136
- Kinshuk — 2026UCD2173
- Akshat — 2026UCD3123

The project is listed in the assignment sheet as “Campus Complaint and Maintenance Portal”. The suggested project scope in that sheet is: submit complaints, categorize issues, track their status, and update resolution details.

Do not infer or assign individual contributions unless the students provide them.

## 3. Project overview — source-grounded

The supplied application is a Flask-based campus complaint and maintenance portal. It provides a browser interface for submitting campus maintenance complaints and viewing complaint records. Complaint records include a title, category, campus location, description, reporter name, status, resolution notes, and creation timestamp.

The dashboard displays four summary counts:
- Total complaints
- Pending complaints
- In Progress complaints
- Resolved complaints

Users can:
- Submit a complaint through a form.
- Choose a category.
- Enter the location or room number and describe the issue.
- View complaint records.
- Filter records by status and category.
- Open an update dialog to change a complaint's status and resolution notes.
- Delete a complaint record.
- View summary counts that are fetched from the backend.

The supplied interface uses the heading “Campus Maintenance & Complaint Portal”, with a “Group 4: Kush | Kinshuk | Akshat” label.

### Problem statement (write in your own polished academic wording)
Campus facility issues such as electrical faults, plumbing problems, internet issues, damaged furniture, and cleanliness concerns need a simple way to be reported and followed up. When reports are handled informally, it can be difficult to organize issue details and monitor whether they are pending, being addressed, or resolved. This project provides a centralized web interface to register and track campus maintenance complaints.

### Objectives
Use these as the project's objectives:
1. Provide a structured form for students or reporters to submit campus maintenance complaints.
2. Categorize and display complaint records, with filtering by category and status.
3. Allow complaint status and resolution notes to be updated, while showing dashboard totals for complaint progress.

### Scope and boundaries
The supplied code supports a basic complaint-record workflow. Do not claim:
- User authentication, role-based access, or admin login.
- Email/SMS/push notifications.
- Assignment of complaints to named technicians or departments.
- File/photo attachments.
- Maps, geolocation, or live tracking.
- Analytics beyond the four dashboard counts.
- Deployment to a public server or production hosting.
- A multi-user permissions model.
- Audit logs or a history of status changes.

The database file supplied is currently empty (zero complaint rows). It contains the `complaints` table schema. Do not present sample complaint counts as real project usage.

## 4. Implemented feature details

### 4.1 Complaint submission
The web form asks for:
- Reporter name / roll number
- Issue summary/title
- Category
- Location / room number
- Detailed description

The HTML form marks these fields as required. The Flask POST endpoint also checks that all five values are non-empty after trimming whitespace. A successful submission is inserted into SQLite and returns a success response and the new record ID.

### 4.2 Categories in the interface
The supplied HTML includes these categories:
- Electrical
- Plumbing
- IT & Internet
- Furniture / Carpentry
- Cleanliness
- Other

The database stores the category as text.

### 4.3 Complaint listing and filtering
The browser loads complaint records from the backend and displays them as cards. Each card shows:
- Issue title
- Status
- Location
- Category
- Reporter name
- Description
- Resolution note, when present

The listing can be filtered using status and category query parameters. Records are ordered by descending ID (newest inserted ID first).

### 4.4 Status tracking and resolution notes
The interface offers three status values:
- Pending
- In Progress
- Resolved

An update dialog allows the user to select a status and enter resolution notes. The frontend sends a PATCH request to the backend. The backend also accepts PUT on the same endpoint.

### 4.5 Dashboard statistics
The `/api/stats` endpoint returns counts for total, pending, in-progress, and resolved complaints. The frontend inserts these values into the four dashboard statistic cards.

### 4.6 Complaint deletion
A delete action is available on each complaint card. The frontend asks for confirmation and sends a DELETE request. The backend deletes the selected record if it exists.

## 5. Technology stack

Use this exact stack based on supplied files:

| Technology | Role in this project |
|---|---|
| Python | Backend application logic and database operations |
| Flask 3.0.0 | Web framework and HTTP route handling |
| SQLite | Persistent storage for complaint records |
| HTML | Structure of the browser interface |
| CSS | Layout, typography, colors, cards, responsive dashboard styling |
| JavaScript | Frontend interactions and asynchronous API requests using `fetch()` |
| JSON | Request and response format between browser and Flask API |

Do not describe this project as a no-database application. Unlike the PhishWise example, Group 4's code uses SQLite through Python's `sqlite3` module.

## 6. Database design

The supplied `database.py` initializes a SQLite table named `complaints`:

| Field | Type / constraint | Purpose |
|---|---|---|
| id | INTEGER PRIMARY KEY AUTOINCREMENT | Unique complaint identifier |
| title | TEXT NOT NULL | Short issue summary |
| category | TEXT NOT NULL | Complaint category |
| location | TEXT NOT NULL | Campus location / room |
| description | TEXT NOT NULL | Detailed issue description |
| reporter_name | TEXT NOT NULL | Name / roll number of reporter |
| status | TEXT DEFAULT 'Pending' | Current workflow status |
| resolution_notes | TEXT DEFAULT '' | Notes about action taken |
| created_at | TIMESTAMP DEFAULT CURRENT_TIMESTAMP | Record creation timestamp |

Mention that `complaints.db` was supplied and currently contains no complaint rows. The application calls `init_db()` on startup, creating the table if it does not already exist.

## 7. Flask API routes — accurately document these

| Endpoint | Method | Purpose |
|---|---|---|
| `/` | GET | Renders `templates/index.html` |
| `/api/stats` | GET | Returns total, pending, in-progress, and resolved counts |
| `/api/complaints` | GET | Returns complaint records; supports optional `status` and `category` filters |
| `/api/complaints/<int:complaint_id>` | GET | Returns one complaint or a 404 response |
| `/api/complaints` | POST | Validates and creates a complaint record |
| `/api/complaints/<int:complaint_id>` | PATCH / PUT | Updates status and/or resolution notes |
| `/api/complaints/<int:complaint_id>` | DELETE | Deletes a complaint record |

Explain methods:
- GET retrieves complaint data or dashboard counts.
- POST creates a new complaint.
- PATCH/PUT updates an existing complaint's status and resolution notes.
- DELETE removes an existing complaint record.

### Validation and error handling visible in supplied code
- The create route rejects a missing/empty JSON body with HTTP 400.
- It checks that title, category, location, description, and reporter name are all non-empty; missing fields return HTTP 422.
- Fetching a nonexistent individual complaint returns HTTP 404.
- Updating or deleting a nonexistent complaint returns HTTP 404.
- Successful complaint creation returns HTTP 201.
- Successful reads/updates/deletes return HTTP 200.
- SQL statements use parameterized values for filters and database writes/lookup.

Be precise: the supplied update route checks that a JSON body exists and that the record exists, but does not validate the incoming status against the three UI choices. Do not claim comprehensive server-side validation beyond what is present. The GET listing route does not validate filter values against an allowlist in the supplied code.

## 8. System architecture and workflows

Create a simple architecture diagram showing:

**User / Browser**  
→ **Frontend (HTML + CSS + JavaScript)**  
→ **HTTP requests using fetch() / Flask routes**  
→ **Python backend logic**  
→ **SQLite database (`complaints.db`)**  
→ **JSON response**  
→ **Frontend refreshes complaint cards and dashboard statistics**

Important implementation details:
- Flask serves the HTML page using `render_template('index.html')`.
- The HTML references CSS at `static/css/style.css`.
- The HTML references JavaScript at `static/js/app.js`.
- JavaScript uses `fetch()` for asynchronous requests.
- `database.py` uses Python's built-in `sqlite3` library.
- The database connection sets `sqlite3.Row` so rows can be converted to dictionaries.
- The backend returns JSON using Flask's `jsonify()`.

### Main user workflow
1. User opens the portal in a browser.
2. The frontend requests dashboard statistics and complaint records.
3. User fills out the complaint form and submits it.
4. JavaScript sends the complaint data as JSON to `POST /api/complaints`.
5. Flask validates the fields and stores the record in SQLite.
6. Frontend refreshes the complaint list and dashboard counts.
7. User may filter records by category or status.
8. User may update status and resolution notes, or delete a record.
9. The frontend refreshes the list and statistics after successful changes.

## 9. User interface and visual direction

The supplied CSS establishes a clean, modern dashboard style:
- Light slate/off-white page background.
- Dark navy/slate navigation bar.
- White cards with subtle borders and shadows.
- Blue primary action color.
- Amber pending status.
- Blue in-progress status.
- Green resolved status.
- Inter font family.
- Dashboard metric cards arranged in a responsive grid.
- Two-column desktop layout: complaint form on the left and complaint list on the right; it collapses to one column below 900px.
- Complaint cards, filter controls, status tags, and an update modal.

Use this visual identity in the report and slides: navy/slate + blue, with amber/blue/green status accents. Keep slides clean, spacious, and diagram-led. Do not imitate the PhishWise cybersecurity theme.

### Screenshots
No genuine screenshots of Group 4's running website were supplied in this package. The assignment-list image is not an application screenshot. Do not reuse PhishWise screenshots as if they belong to Group 4. Create clearly labeled screenshot placeholders or ask the students to capture:
1. Full dashboard/homepage.
2. Complaint submission form.
3. Complaint list with status/category filters.
4. Update-status modal and a record showing resolution notes.
5. Dashboard metrics after adding test/demo complaints.

If screenshots are not provided, keep placeholders clearly marked and do not invent a screenshot.

## 10. Testing and evidence — critical accuracy requirement

No Group 4 test scripts, test output, terminal captures, or test report were supplied. Therefore:
- Do not claim that automated tests passed.
- Do not invent test counts, coverage percentages, performance numbers, or test results.
- Do not copy the PhishWise example's “7 logic tests + 9 API tests” figures.
- In the report, include a proposed test plan clearly labeled **“Suggested tests to perform”**, not completed tests.
- If a testing section is required, provide a table with test case, expected result, and an empty “Actual result / status” column for the students to fill after testing.

Suggested manual test cases:
1. Open the home page.
2. Submit a complaint with all required fields.
3. Attempt submission with one required field blank.
4. Confirm the new record appears in the list.
5. Filter by each status.
6. Filter by each category.
7. Open one complaint and retrieve its details through the single-record endpoint.
8. Update a complaint from Pending to In Progress.
9. Add resolution notes and save.
10. Update a complaint to Resolved.
11. Delete a complaint and confirm it disappears.
12. Confirm dashboard totals change after create/update/delete.
13. Request a nonexistent complaint ID and confirm a 404 response.

The students should run these tests and replace blank statuses with actual observed results before final submission.

## 11. Limitations and future scope

### Limitations supported by the current implementation
- No login/authentication or role-based permissions are implemented.
- The app does not identify or assign a complaint to a technician/department.
- No notification system is present.
- No image/file upload is present.
- No complaint activity/audit history is stored.
- The interface is a basic dashboard and complaint tracker.
- The supplied database is empty; no real complaint activity data was supplied.
- No automated test evidence was supplied.

### Possible future enhancements (label as future scope, not implemented)
- Student and maintenance/admin login with role-based permissions.
- Assign complaints to a maintenance department or staff member.
- Email or in-app notifications on status changes.
- Upload photographs of maintenance issues.
- Complaint priority/severity levels.
- Search by keyword and date range.
- Status-change history and timestamps.
- More advanced analytics and downloadable reports.
- Accessibility and usability improvements.
- Deployment to a secure campus server.

## 12. Installation and local run instructions

The supplied dependency file contains `Flask==3.0.0`.

Suggested instructions for the report:
1. Install Python.
2. Open a terminal in the `project/` directory.
3. Install dependencies:
   `python -m pip install -r requirements.txt`
4. Start the application:
   `python app.py`
5. Open `http://127.0.0.1:5000` in a browser.
6. Stop the server with `Ctrl+C`.

The archive organizes the files into the directory layout referenced by the supplied HTML:
- `project/app.py`
- `project/database.py`
- `project/complaints.db`
- `project/requirements.txt`
- `project/templates/index.html`
- `project/static/css/style.css`
- `project/static/js/app.js`

Do not claim the app has been deployed online.

## 13. College guideline alignment

The supplied mini-project worksheet asks students to demonstrate:
- Python backend using Flask.
- Appropriate API routes and HTTP methods (GET, POST, PUT/PATCH, DELETE wherever required).
- JSON API responses.
- Input validation and error handling.
- Frontend integration through API requests.
- Testing of main features.
- Source code and basic run instructions.
- Screenshots and a working demonstration.

The report should explicitly map Group 4's implementation to these points. It is acceptable to explain that PUT/PATCH and DELETE are used because this project supports updating and deleting complaint records. Do not force endpoints from the worksheet's generic `/api/items` example.

## 14. Recommended report structure

Use the PhishWise report only as a model for organization and detail. Create a Group 4 report with:
1. Cover page — project title, group number, all three members/roll numbers, institution, academic year.
2. Abstract / project overview.
3. Problem statement and objectives.
4. Scope and key features.
5. Technology stack.
6. System architecture and workflow diagram.
7. Database design / schema.
8. Flask API routes and HTTP methods.
9. Frontend implementation and user interface.
10. Validation and error handling.
11. Testing plan and actual test evidence (leave results blank/placeholders until tested).
12. Limitations and future scope.
13. Conclusion and learning outcomes.
14. Installation and run instructions.
15. Appendix with genuine application screenshots and selected source-code excerpts, if useful.

Use formal, clear student-project language. Avoid unnecessarily inflated claims.

## 15. Recommended PowerPoint structure

Create a presentation of approximately 9–11 slides:
1. Title — Campus Complaint and Maintenance Portal; Group 4; three members and roll numbers; NSUT; 2026.
2. Problem statement — why campus complaints need organized reporting and tracking.
3. Objectives and project scope.
4. Key features — submit, categorize, view/filter, update status/notes, delete, dashboard counts.
5. Technology stack — Python, Flask, SQLite, HTML, CSS, JavaScript, JSON.
6. Architecture diagram — browser/frontend → Flask/API → Python/database → JSON response.
7. Database and API overview — schema summary and key endpoints.
8. Application walkthrough — use genuine screenshots only; otherwise use labeled placeholders.
9. Testing — proposed test plan; actual results must be added by students after execution.
10. Limitations and future scope.
11. Conclusion / Thank You.

Use concise slide text, readable diagrams, consistent colors, and speaker notes or a short presenter script if useful. The deck should be understandable in a short classroom presentation.

## 16. Final verification checklist for students

Before submitting, Group 4 must:
- Confirm member names and roll numbers.
- Run the project from the packaged folder.
- Verify the home page and all API routes.
- Test create, read, filter, update, delete, and dashboard count behavior.
- Check that the database is being written to the intended `complaints.db`.
- Capture genuine screenshots of their running application.
- Record actual testing outcomes and terminal evidence, if any.
- Confirm whether the faculty requires a specific report format, page limit, or filename.
- Review every claim in the report and slides for accuracy.
- Add individual contribution details only if agreed by all members.

**Do not present this brief as evidence that testing has already been completed.**
